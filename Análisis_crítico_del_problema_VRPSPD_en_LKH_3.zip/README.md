# Plantilla LaTeX VRPSPD

Esta carpeta adapta el formato del archivo `Grupo16_Solemne_2.zip` al Trabajo Final sobre VRPSPD y LKH-3.

## Archivos

- `main.tex`: documento principal con portada UNAB, índice, encabezado con logo y secciones del enunciado.
- `assets/logo_unab.jpg`: logo institucional reutilizado desde el ZIP de referencia.

## Compilación

Desde esta carpeta:

```powershell
pdflatex main.tex
pdflatex main.tex
```

En esta máquina no se detectó `pdflatex`, `xelatex` ni `latexmk`, por lo que la compilación debe hacerse en Overleaf o en una instalación local de TeX Live/MiKTeX.

## Nota importante

El enunciado pide paper breve en formato IEEE. Esta plantilla replica el formato institucional del ZIP entregado como referencia. Si el docente exige estrictamente IEEE, conviene convertir esta estructura a la clase `IEEEtran`.
